document.addEventListener('DOMContentLoaded', () => {
    
    // Initialize EmailJS
    emailjs.init("FlBkZT03kT8Ww7yss"); 

    // ------------------------------------------------------------------
    // 1. Search Bar
    // ------------------------------------------------------------------
    const searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const searchInput = document.getElementById('search-input');
            const query = searchInput.value.trim();
            if (query === "") {
                alert("Please enter a search term.");
                return;
            }
            alert(`Searching for: "${query}"`);
            searchInput.value = '';
        });
    }

    // ------------------------------------------------------------------
    // 2. CART FUNCTIONALITY
    // ------------------------------------------------------------------
    const cartCountElement = document.getElementById('cart-count');
    let currentCartCount = 0;
    const MAX_BOOKS = 5;

    const allButtons = document.querySelectorAll('button');

    allButtons.forEach(button => {
        if (button.textContent.trim() === "Book to borrow") {
            button.addEventListener('click', function() {
                
                if (currentCartCount >= MAX_BOOKS) {
                    alert("⚠️ Limit Reached: You can only borrow a maximum of 5 books.");
                } else {
                    currentCartCount++;
                    cartCountElement.textContent = currentCartCount;
                    
                    const originalText = button.textContent;
                    button.textContent = "Added! ✓";
                    button.style.backgroundColor = "#4CAF50";
                    
                    setTimeout(() => {
                        button.textContent = originalText;
                        button.style.backgroundColor = "";
                    }, 1000);
                }
            });
        }
    });


    // ------------------------------------------------------------------
    // 3. Form Validation & EmailJS Sending
    // ------------------------------------------------------------------
    const contactForm = document.getElementById('contact-form');
    const enquiryForm = document.getElementById('enquiry-form');

    function handleFormSubmission(event, formType) {
        event.preventDefault();
        const form = event.target;
        let isValid = true;
        let errorMessage = '';

        // Validation
        form.querySelectorAll('[required]').forEach(input => {
            if (!input.value.trim()) {
                isValid = false;
                errorMessage += `\n* ${input.name} is required.`;
            }
        });

        if (formType === 'contact') {
            const emailInput = form.querySelector('input[name="email"]');
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (emailInput && !emailPattern.test(emailInput.value.trim())) {
                isValid = false;
                errorMessage += '\n* Please enter a valid email address.';
            }
        } else if (formType === 'enquiry') {
            const phoneInput = form.querySelector('input[name="phone"]');
            const phoneValue = phoneInput ? phoneInput.value.replace(/\s+/g, '') : '';
            if (phoneInput && (phoneValue.length < 8 || !/^\d+$/.test(phoneValue))) {
                isValid = false;
                errorMessage += '\n* Phone number must be at least 8 digits.';
            }
        }

        const errorDisplay = form.querySelector('.error-message');
        if (errorDisplay) errorDisplay.innerHTML = '';

        if (!isValid) {
            if (errorDisplay) {
                errorDisplay.innerHTML = `**Errors:** ${errorMessage}`;
                errorDisplay.style.color = 'red';
            }
            alert(`Please fix errors:\n${errorMessage}`);
            return;
        }

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.innerText;
        submitBtn.innerText = "Sending...";
        submitBtn.disabled = true;

        const serviceID = "service_t4pswmj"; 
        const templateID = "template_wp31fkg"; 

        emailjs.sendForm(serviceID, templateID, form)
            .then(() => {
                alert('SUCCESS! Your message has been sent.');
                form.reset();
            }, (err) => {
                alert('FAILED to send message. Please try again later.\nError: ' + JSON.stringify(err));
            })
            .finally(() => {
                submitBtn.innerText = originalBtnText;
                submitBtn.disabled = false;
            });
    }

    if (contactForm) contactForm.addEventListener('submit', (e) => handleFormSubmission(e, 'contact'));
    if (enquiryForm) enquiryForm.addEventListener('submit', (e) => handleFormSubmission(e, 'enquiry'));
});

// ------------------------------------------------------------------
// 4. Lightbox Functionality
// ------------------------------------------------------------------
const galleryImages = [
    { src: 'Images/B.webp', caption: 'Library Interior' },
    { src: 'Images/A.jpeg', caption: 'Reading Area' },
    { src: 'Images/D.webp', caption: 'Book Collection' },
    { src: 'Images/E.webp', caption: 'Study Facility' },
    { src: 'Images/F.webp', caption: 'Kids Section' },
    { src: 'Images/Poster.jpeg', caption: 'Library Poster' }
];

let currentImageIndex = 0;

function openLightbox(src) {
    const lightbox = document.getElementById('lightbox');
    currentImageIndex = galleryImages.findIndex(img => img.src === src);
    if (currentImageIndex === -1) currentImageIndex = 0;

    updateLightboxContent();
    lightbox.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
    document.body.style.overflow = 'auto';
}

function changeImage(direction) {
    currentImageIndex += direction;
    if (currentImageIndex < 0) currentImageIndex = galleryImages.length - 1;
    else if (currentImageIndex >= galleryImages.length) currentImageIndex = 0;
    updateLightboxContent();
}

function updateLightboxContent() {
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxCaption = document.getElementById('lightbox-caption');
    lightboxImg.src = galleryImages[currentImageIndex].src;
    lightboxCaption.textContent = galleryImages[currentImageIndex].caption;
}

window.addEventListener('click', (e) => {
    const lightbox = document.getElementById('lightbox');
    if (e.target === lightbox) closeLightbox();
});